#!/bin/sh
echo 'Executable permissions.'